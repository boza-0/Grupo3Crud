package principal;

import controlador.ControladorConsulta;
import conexion.JDBC;
import vista.VistaConsulta;

import java.io.File;

/**
 * 
 * author BERJANO MUÑOZ, RAFAEL
 * author BOZA VILLAR, RICARDO
 * author CALIXTO DEL HOYO, JUAN
 * author GARCÍA MARCHENA, ÁLVARO
 */
public class RuralHome {

    public static void main(String[] args) {

        JDBC jdbc = JDBC.getInstancia();
        jdbc.setConexion(new File("bdrural.properties"));

        VistaConsulta vista = new VistaConsulta();
        new ControladorConsulta(vista, jdbc);
        
        vista.setVisible(true);
    }
}
