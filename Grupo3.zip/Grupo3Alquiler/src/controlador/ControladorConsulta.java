package controlador;

import conexion.JDBC;
import modelo.TipoDeAlojamiento;
import vista.VistaConsulta;
import vista.VistaResultados;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * author BERJANO MUÑOZ, RAFAEL
 * author BOZA VILLAR, RICARDO
 * author CALIXTO DEL HOYO, JUAN
 * author GARCÍA MARCHENA, ÁLVARO
 */
public class ControladorConsulta {

    private VistaConsulta vista;
    private JDBC jdbc;

    public ControladorConsulta(VistaConsulta vista, JDBC jdbc) {
        this.vista = vista;
        this.jdbc = jdbc;
        inicializar();
    }

    private void inicializar() {

        cargarTiposDeAlojamiento();

        vista.getBuscarButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscar();
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void cargarTiposDeAlojamiento() {

        vista.getTipoDeAlojamientoComboBox().removeAllItems();

        List<TipoDeAlojamiento> tipos = new ArrayList<>();

        try {
            jdbc.setSentenciaSQL(
                    "SELECT codigo, descripcion FROM tipos ORDER BY codigo");

            jdbc.ejecutarConsulta();
            ResultSet rs = jdbc.getCursor();

            while (rs != null && rs.next()) {
                TipoDeAlojamiento tipo = new TipoDeAlojamiento();
                tipo.setCodigo(rs.getInt("codigo"));
                tipo.setDescripcion(rs.getString("descripcion"));
                tipos.add(tipo);
            }

            jdbc.cerrarCursor();

        } catch (Exception e) {
            e.printStackTrace();
        }

        for (TipoDeAlojamiento tipo : tipos) {
            vista.getTipoDeAlojamientoComboBox().addItem(tipo);
        }

        vista.getTipoDeAlojamientoComboBox().setSelectedIndex(-1);
    }

    private void buscar() {

        String provincia = vista.getProvinciaTxt().getText();

        Integer tipo = null;
        if (vista.getTipoDeAlojamientoComboBox().getSelectedItem() != null) {
            tipo = ((TipoDeAlojamiento) vista.getTipoDeAlojamientoComboBox().getSelectedItem())
                    .getCodigo();
        }

        boolean poblacion = vista.getEnPoblacionCheckBox().isSelected();
        boolean aislado = vista.getAisladoCheckBox().isSelected();

        Integer capacidad = null;
        if (!vista.getCapacidadTxt().getText().trim().isEmpty()) {
            capacidad = Integer.parseInt(vista.getCapacidadTxt().getText());
        }

        StringBuilder sql =
                new StringBuilder("SELECT * FROM alojamientos WHERE alquilado = 0");

        List<Object> parametros = new ArrayList<>();

        if (provincia != null && !provincia.trim().isEmpty()) {
            sql.append(" AND UPPER(provincia) = UPPER(?)");
            parametros.add(provincia.trim());
        }

        if (tipo != null) {
            sql.append(" AND tipo = ?");
            parametros.add(tipo);
        }

        if (poblacion ^ aislado) {
            sql.append(" AND ubicacion = ?");
            parametros.add(poblacion ? "POBLACION" : "AISLADO");
        }

        if (capacidad != null) {
            sql.append(" AND capacidad = ?");
            parametros.add(capacidad);
        }

        VistaResultados vistaResultados = new VistaResultados();
        new ControladorResultados(
                vistaResultados,
                sql.toString(),
                parametros,
                jdbc);

        vistaResultados.setVisible(true);
        vista.dispose();
    }
}
