package controlador;

import conexion.JDBC;

import modelo.Alojamiento;
import modelo.Ubicacion;

import vista.VistaConsulta;
import vista.VistaResultados;
import vista.VistaFinalizacion;

import javax.swing.table.DefaultTableModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * author BERJANO MUÑOZ, RAFAEL
 * author BOZA VILLAR, RICARDO
 * author CALIXTO DEL HOYO, JUAN
 * author GARCÍA MARCHENA, ÁLVARO
 */
public class ControladorResultados {

    private VistaResultados vista;
    private List<Alojamiento> resultados;
    private List<Alojamiento> seleccionados;
    private JDBC jdbc;

    public ControladorResultados(
            VistaResultados vista,
            String sql,
            List<Object> parametros,
            JDBC jdbc) {

        this.vista = vista;
        this.jdbc = jdbc;
        this.seleccionados = new ArrayList<>();

        cargarResultados(sql, parametros);
        inicializar();
    }

    private void cargarResultados(String sql, List<Object> parametros) {

        resultados = new ArrayList<>();

        for (Object param : parametros) {
            if (param instanceof String) {
                sql = sql.replaceFirst("\\?", "'" + param + "'");
            } else {
                sql = sql.replaceFirst("\\?", param.toString());
            }
        }

        try {
            jdbc.setSentenciaSQL(sql);
            jdbc.ejecutarConsulta();
            ResultSet rs = jdbc.getCursor();

            while (rs != null && rs.next()) {
                Alojamiento a = new Alojamiento();
                a.setReferencia(rs.getInt("referencia"));
                a.setNombre(rs.getString("nombre"));
                a.setPoblacion(rs.getString("poblacion"));
                a.setProvincia(rs.getString("provincia"));
                a.setCapacidad(rs.getInt("capacidad"));
                a.setTipo(rs.getInt("tipo"));
                a.setUbicacion(Ubicacion.valueOf(rs.getString("ubicacion")));
                a.setAlquilado(rs.getBoolean("alquilado"));

                resultados.add(a);
            }

            jdbc.cerrarCursor();

        } catch (Exception e) {
            e.printStackTrace();
        }

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[]{"REFERENCIA", "NOMBRE", "PROVINCIA", " "}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Alojamiento a : resultados) {
            modelo.addRow(new Object[]{
                a.getReferencia(),
                a.getNombre(),
                a.getProvincia(),
                "Alquilar"
            });
        }

        vista.getTablaResultados().setModel(modelo);
        vista.getFinalizarAlquilerButton().setEnabled(false);
    }

    private void inicializar() {

        vista.getTablaResultados().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = vista.getTablaResultados().rowAtPoint(e.getPoint());
                int columna = vista.getTablaResultados().columnAtPoint(e.getPoint());

                if (fila != -1 && columna == 3) {
                    alquilarFila(fila);
                }
            }
        });

        vista.getVolverPrincipalButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                volver();
            }
        });

        vista.getFinalizarAlquilerButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                finalizarAlquiler();
            }
        });
    }

    private void alquilarFila(int fila) {

        Alojamiento a = resultados.get(fila);

        seleccionados.add(a);
        resultados.remove(fila);

        ((DefaultTableModel) vista.getTablaResultados().getModel())
                .removeRow(fila);

        vista.getFinalizarAlquilerButton()
                .setEnabled(!seleccionados.isEmpty());
    }

    private void finalizarAlquiler() {

        for (Alojamiento a : seleccionados) {
            jdbc.setSentenciaSQL(
                "UPDATE alojamientos SET alquilado = 1 WHERE referencia = " +
                a.getReferencia()
            );
            jdbc.ejecutarConsultaActualizable();
        }

        int totalAlojamientos = seleccionados.size();
        int totalPersonas = 0;

        for (Alojamiento a : seleccionados) {
            totalPersonas += a.getCapacidad();
        }

        VistaFinalizacion vistaFinal =
                new VistaFinalizacion(totalAlojamientos, totalPersonas);

        vistaFinal.setVisible(true);
        vista.dispose();
    }

    private void volver() {

        seleccionados.clear();

        VistaConsulta vistaConsulta = new VistaConsulta();
        new ControladorConsulta(vistaConsulta, jdbc);
        vistaConsulta.setVisible(true);
        vista.dispose();
    }
}
