package conexion;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import java.sql.*;

import java.util.Properties;

/**
 *
 * author BERJANO MUÑOZ, RAFAEL
 * author BOZA VILLAR, RICARDO
 * author CALIXTO DEL HOYO, JUAN
 * author GARCÍA MARCHENA, ÁLVARO
 */
public class JDBC {

    private static JDBC instancia;

    private Connection conexion;
    private String sentenciaSQL;
    private ResultSet cursor;

    private JDBC() {}

    public static JDBC getInstancia() {
        if (instancia == null) {
            instancia = new JDBC();
        }
        return instancia;
    }

    public boolean setConexion(File properties) {
        try {
            Properties props = new Properties();

            try (InputStream is = new FileInputStream(properties)) {
                props.load(is);
            }

            String driver = props.getProperty("driver");
            String url = props.getProperty("url");
            String usuario = props.getProperty("usuario");
            String password = props.getProperty("password");

            Class.forName(driver);
            conexion = DriverManager.getConnection(url, usuario, password);

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public Connection getConexion() {
        return conexion;
    }

    public void setSentenciaSQL(String strSQL) {
        this.sentenciaSQL = strSQL;
    }

    /** SELECT */
    public boolean ejecutarConsulta() {
        try {
            Statement st = conexion.createStatement();
            cursor = st.executeQuery(sentenciaSQL);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            cursor = null;
            return false;
        }
    }

    /** INSERT / UPDATE / DELETE */
    public boolean ejecutarConsultaActualizable() {
        try {
            Statement st = conexion.createStatement();
            st.executeUpdate(sentenciaSQL);
            cursor = null;
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ResultSet getCursor() {
        return cursor;
    }

    public boolean cerrarCursor() {
        try {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean cerrarConexion() {
        try {
            if (conexion != null) {
                conexion.close();
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}
