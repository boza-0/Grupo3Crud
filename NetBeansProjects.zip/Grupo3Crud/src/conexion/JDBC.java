package conexion;

import java.sql.*;
import java.io.InputStream;
import java.util.Properties;

public class JDBC {

    private static JDBC instancia;

    private Connection conexion;
    private String sentenciaSQL;
    private ResultSet cursor;

    private JDBC() {}

    public static JDBC getInstancia() {
        if (instancia == null) {
            instancia = new JDBC();
        }
        return instancia;
    }

    public boolean setConexion(String rutaProperties) {
        try {
            Properties propiedades = new Properties();
            InputStream is = JDBC.class
                    .getClassLoader()
                    .getResourceAsStream(rutaProperties);

            if (is == null) {
                throw new RuntimeException(
                        "No se encuentra el fichero de propiedades: " + rutaProperties
                );
            }

            propiedades.load(is);

            String driver = propiedades.getProperty("driver");
            String url = propiedades.getProperty("url");
            String usuario = propiedades.getProperty("usuario");
            String password = propiedades.getProperty("password");

            Class.forName(driver);
            conexion = DriverManager.getConnection(url, usuario, password);

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Connection getConexion() {
        return conexion;
    }

    public void setSentenciaSQL(String strSQL) {
        this.sentenciaSQL = strSQL;
    }

    /** SELECT */
    public boolean ejecutarConsulta() {
        try {
            Statement st = conexion.createStatement();
            cursor = st.executeQuery(sentenciaSQL);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            cursor = null;
            return false;
        }
    }

    /** INSERT / UPDATE / DELETE */
    public boolean ejecutarConsultaActualizable() {
        try {
            Statement st = conexion.createStatement();
            st.executeUpdate(sentenciaSQL);
            cursor = null;
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ResultSet getCursor() {
        return cursor;
    }

    public boolean cerrarCursor() {
        try {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean cerrarConexion() {
        try {
            if (conexion != null) {
                conexion.close();
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}
