package principal;

import conexion.JDBC;
import controlador.ControladorConsulta;
import vista.VistaConsulta;

/**
 * 
 * author BERJANO MUÑOZ, RAFAEL
 * author BOZA VILLAR, RICARDO
 * author CALIXTO DEL HOYO, JUAN
 * author GARCÍA MARCHENA, ÁLVARO
 */
public class RuralHome {

    public static void main(String[] args) {

        JDBC jdbc = JDBC.getInstancia();
        jdbc.setConexion("conexion/bdrural.properties");

        VistaConsulta vista = new VistaConsulta();
        new ControladorConsulta(vista, jdbc);
        vista.setVisible(true);
    }
}
